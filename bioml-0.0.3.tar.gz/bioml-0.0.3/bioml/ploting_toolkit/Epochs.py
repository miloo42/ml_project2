#Dash imports
import dash
import dash_core_components as dcc
from dash.dependencies import Input, Output, State
import dash_html_components as html
import plotly.graph_objs as go

import numpy as np

def Epochs_div2(Epochs,labels, before, after):
    #Create list for each element of set
    Boxes = []
    print(Epochs.shape)
    for idx,i in enumerate(labels):
        if i == 0:
            color = 'rgba(0, 0, 0,0.1)'
        elif i == 1:
            color = 'rgba(255, 0, 0,0.1)'
        elif i == 2:
            color = 'rgba(0, 255, 0,0.1)'
        elif i == 3:
            color = 'rgba(0, 0, 255,0.1)'
        elif i == 4:
            color = 'rgba(255, 0, 255,0.1)'
            
        if idx < 1000:
            
            Boxes.append(go.Scattergl(x=np.linspace(before,after,Epochs.shape[1]), 
                                    y=Epochs[idx,:].reshape((-1,)),
                                    marker = dict(
                                                size = 10,
                                                color = color,
                                                line = dict(
                                                    width = 2,
                                                    color = color
                                                    )   
                                                )
                                    )
                                                )
            print(idx)
            
    
    Boxes.append(go.Scatter(x=np.linspace(before,after,Epochs.shape[1]), 
                                y=np.mean(Epochs[np.argwhere(labels==1),:],axis = 0).reshape((-1,))*3, 
                                name = 'y = ' + str(1),
                                marker = dict(
                                                size = 10,
                                                color = 'rgb(0, 0, 0)',
                                                line = dict(
                                                    width = 10,
                                                    color = color
                                                    )   
                                                )
                                    ))

        

    return html.Div([dcc.Graph(id='scatter2D_plot', 
                               figure={
                                   'data': Boxes,
                                   'layout': go.Layout(title= 'Time series of Epochs', 
                                                      xaxis = dict( title= 'Time [ms]'),
                                                      yaxis = dict( title= 'Epochs')
                                                      )
                               })
                   ])
                                   
def Epochs_div(Epochs,labels, before, after):
    #Create list for each element of set
    Boxes = []
    for idx,i in enumerate(set(labels)):
        Boxes.append(go.Scatter(x=np.linspace(before,after,Epochs.shape[1]), 
                                y=np.mean(Epochs[np.argwhere(labels==i),:],axis = 0).reshape((-1,)), 
                                name = 'y = ' + str(i)))
        
    return html.Div([dcc.Graph(id='scatter2D_plot', 
                               figure={
                                   'data': Boxes,
                                   'layout': go.Layout(title= 'Time series of Epochs', 
                                                      xaxis = dict( title= 'Time [ms]'),
                                                      yaxis = dict( title= 'Epochs')
                                                      )
                               })
                   ])