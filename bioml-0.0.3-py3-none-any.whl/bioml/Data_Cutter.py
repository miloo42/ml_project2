"""@package docstring
This module contains functions to cut train/validation/test sets. 

L_*** functions are Low level functions that work with pandas dataframe containing only the data and time as index
H_*** functions are High level functions that accept as argument pandas dataframe with standard "app" structure (with columns 'subject_id' and 'condition') and will call L_*** functions
HH_*** functions are even Higher level functions that accept a list of pandas dataframe with standard "app" structure and will call H_*** functions
"""

import pandas as pd


def H_Cut_Data_on_percentage(Tables, Labels, val_percentage, test_percentage):
    """
    Add a column with values between 'train', 'validation' and 'test' to assign data based on percentages (validation percentage can be 0 but not test)

    :param Tables: list of dataframes to deal with more than one stream of data
    :param Labels: dataframe with standard "app" structure 
    :param val_percentage: float [0,1]
    :param test_percentage: float (0,1]
    :return: list of dataframes with one extra columns for assigned set and Labels accordingly
    """

    if val_percentage >= 1 or test_percentage >=1:
        raise ValueError('percentages should be between 0 and 1')
    if test_percentage == 0:
        raise ValueError('Test percentage cannot be 0')
    
    for table in Tables:
        table['set'] = 'train'
        
        distinct_recordings = table[['subject_id','condition']].drop_duplicates().values

        #cut each recording
        for subj,cdt_nb in distinct_recordings:

            #get data from one recording
            table_rec = table[table['subject_id'] == subj][table['condition'] == cdt_nb]

            #update table with all recordings (cutting only one recording)
            table.loc[table_rec.loc[table_rec.iloc[int(len(table_rec)*(1-test_percentage)):,:].index.values].index,'set'] = 'test'
            if val_percentage != 0:
                table.loc[table_rec.loc[table_rec.iloc[(int(len(table_rec)) - int(len(table_rec)*test_percentage) - int(len(table_rec)*val_percentage)):(int(len(table_rec)) - int(len(table_rec)*test_percentage)),:].index.values].index,'set'] = 'validation'

    Labels['set'] = 'train'
    
    distinct_labels_recordings = Labels[['subject_id','condition']].drop_duplicates().values
    
    for subj,cdt_nb in distinct_labels_recordings:
        Labels_rec = Labels[Labels['subject_id'] == subj][Labels['condition'] == cdt_nb]
        
        Labels.loc[Labels_rec.loc[Labels_rec.iloc[int(len(Labels_rec)*(1-test_percentage)):,:].index.values].index,'set'] = 'test'
        if val_percentage != 0:
            Labels.loc[Labels_rec.loc[Labels_rec.iloc[(int(len(Labels_rec)) - int(len(Labels_rec)*test_percentage) - int(len(Labels_rec)*val_percentage)):int(len(Labels_rec)) - int(len(Labels_rec)*test_percentage),:].index.values].index,'set'] = 'validation'
            
    return Tables, Labels

def H_Cut_Data_on_recording(Tables, Labels, val_recording, test_recording):
    """ Not implemented yet """
    print("Not implemented")
    return