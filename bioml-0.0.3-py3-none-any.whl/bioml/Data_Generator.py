"""@package docstring
This module contains a generator to feed npy files to a deep network.
"""

import numpy as np
import os


class NumpyDataGenerator():

    def __init__(self, dataframe, directory,x_col, y_col):
        """Constructor can be expanded,
           with batch size, dimension etc.
        """
    
        self.dataframe = dataframe
        self.directory = directory
        self.x_col = x_col
        self.y_col = y_col
        
        all_files = os.listdir(self.directory)
        
        self.tot_correct_files = 0
        
        self.index = 0
        for file in all_files:
            if file.split('.')[1] == self.dataframe[x_col].iloc[0].split('.')[1]:
                self.tot_correct_files += 1 
        
        print("found {} images in directory".format(self.tot_correct_files))
    
    def __getitem__(self):
        for index in range(self.tot_correct_files):
            'Get next batch'
            # Get name of file to load
            filename = self.dataframe[self.x_col].iloc[index]

            #Set of labels
            self.labels = self.dataframe[self.y_col].iloc[index].values

            # Set of X_train

            self.X = np.expand_dims(np.load(self.directory + filename), axis=-1)
            

            yield (self.X, self.labels)
