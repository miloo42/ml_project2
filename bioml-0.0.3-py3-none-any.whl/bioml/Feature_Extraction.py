"""@package docstring
This module contains functions to extract features from the data in standard "app" architecture
Feature extraction is divided in different levels the "basic" BFE extract from one window of one channel up to "super high" SHFE that takes into account high level data structure

warning: The description of the functions in this module can be outdated
"""

import numpy as np
import pandas as pd

import multiprocessing as mp
import functools
import sys

from sklearn.decomposition import FastICA, PCA, FactorAnalysis
from sklearn import preprocessing

import warnings


import bioml.pyeeg as pyeeg

#################################################################################################
# DEFINE FEATURES
# FEATURE DEFINITION
class Feature():
    """ 
    Feature Class:

    It defines a feature with attributes: name, operation to perform (it is a function), a type of signal it should be used for (not used) and a message to be printed in the GUI app
    It has on method to perform the operation on data
    """
    def __init__(self,name,operation,message,_type = ['EEG','EMG']):
        """ 
        _constructor
        :param name: String, Name of the feature
        :param operation: Function, operation on the data to give the feature
        :param message: GUI message
        :param type: Array of String, Type of data (EEG, EMG,...)
        """
        self.name = name
        self.operation = operation
        self.type = _type
        self.GUImessage = message

    def compute_feature(self,data, fs):
        """
        perform operation defined in init on data

        "param data: numpy 1D array containing data to perform operation on (usually one window of one channel)
        "param fs: sampling frequency of data
        """
        return self.operation(data, fs)

class DefinedFeatures():
    """
    Class containing all the features defined so far
    Basically a dictionary of defined features
    To create new feature simply add one in init with its compute function 
    """
    def __init__(self):
        """ 
        _constructor
        Define a dict containing all the Feature classes defined so far
        """
        self.features = {}
        self.features['MAV'] = Feature('MAV', self.computeMAV, "Mean Absolute Value", ['EMG','EEG']) 
        self.features['WL'] = Feature('WL',    self.computeWL ,   "Wavelength", ['EMG','EEG']) 
        self.features['MaxAV'] = Feature('MaxAV', self.computeMaxAV, "Maximum Absuolute Value", ['EMG','EEG'])
        self.features['STD'] = Feature('STD', self.computeSTD, "Standard Deviation", ['EMG','EEG'])
        self.features['ZC'] = Feature('ZC', self.computeZC, "Zero Crossing", ['EMG','EEG'])
        self.features['SSC'] = Feature('SSC', self.computeSSC, "Slope Sign Change", ['EMG','EEG'])
        self.features['RMS'] = Feature('RMS', self.computeRMS, "Root Mean Square", ['EMG','EEG'])
        self.features['WAMP'] = Feature('WAMP', self.computeWAMP, "Wilson Amplitude", ['EMG','EEG'])
        self.features['LOG'] = Feature('LOG', self.computeLOG, "Log Detector", ['EMG','EEG'])
        
        self.features['7_12'] = Feature('7_12', self.compute7_12, "Power Spectrum (7-12Hz)", ['EMG','EEG']) 
        self.features['12_30'] = Feature('12_30', self.compute12_30, "Power Spectrum (12-30Hz)", ['EMG','EEG']) 
        self.features['30_50'] = Feature('30_50', self.compute30_50, "Power Spectrum (30-50Hz)", ['EMG','EEG']) 
        self.features['50_100'] = Feature('50_100', self.compute50_100, "Power Spectrum (50-100Hz)", ['EMG','EEG']) 
        self.features['100_150'] = Feature('100_150', self.compute100_150, "Power Spectrum (100-150Hz)", ['EMG','EEG']) 
        self.features['150_400'] = Feature('150_400', self.compute150_400, "Power Spectrum (150-400Hz)", ['EMG','EEG']) 

        self.fs = None
        
    def computeMAV(self,signal, fs):
        return np.mean(np.absolute(signal))

    def computeWL(self,signal, fs):
        WL = 0
        for y in range(1,len(signal)-1):    
            WL += np.absolute(signal[y]-signal[y-1])
        WL = WL/len(signal)
        return WL

    def computeMaxAV(self,signal, fs):
        return np.max(np.absolute(signal))
    
    def computeSTD(self,signal, fs):
        return np.std(signal)
    
    def computeZC(self,signal, fs):
        ZC = 0
        for y in range(1,len(signal)-1): 
            if (signal[y] > 0 and signal[y-1] < 0) or (signal[y] < 0 and signal[y-1] > 0):
                if np.abs(signal[y] - signal[y-1]) > 0.001: #Threshold is 0.2*STD but signal should be normalized (0.02)
                    ZC += 1
        return ZC
    
    def computeSSC(self,signal, fs):
        SSC = 0
        for y in range(1,len(signal)-2): 
            if (signal[y] > signal[y-1] and signal[y] > signal[y+1]) or (signal[y] < signal[y-1] and signal[y] < signal[y+1]):
                if np.abs(signal[y] - signal[y-1]) > 0.03 or np.abs(signal[y] - signal[y+1]) > 0.03: #Threshold is 0.05*STD but signal should be normalized
                    SSC += 1
        return SSC
    
    def computeRMS(self,signal, fs):
        return np.sqrt((1./len(signal))*np.sum(signal**2))
    
    def computeWAMP(self,signal, fs):
        WAMP = 0
        for y in range(1,len(signal)-1): 
            if np.abs(signal[y] - signal[y-1]) > 0.01: #Threshold is 1*STD but signal should be normalized (0.1)
                WAMP += 1
        return WAMP
    
    def computeLOG(self, signal,fs): #avant il ny avait pas de log here
        return np.sum(np.log(np.abs(signal)))*np.exp(1/len(signal)) # exp(1/N)*[Sum i = 0 -> N {log(abs(Xi))}]
    
    def compute7_12(self,signal, fs):
        spectrum = pyeeg.bin_power(list(signal),list([5,7,12,30,50,100,150,400]),fs)
        return spectrum[1][1] #low freq
    
    def compute12_30(self,signal, fs):
        spectrum = pyeeg.bin_power(list(signal),list([5,7,12,30,50,100,150,400]),fs)
        return spectrum[1][2] #low freq
    
    def compute30_50(self,signal, fs):
        spectrum = pyeeg.bin_power(list(signal),list([5,7,12,30,50,100,150,400]),fs)
        return spectrum[1][3] #low freq
    
    def compute50_100(self,signal, fs):
        spectrum = pyeeg.bin_power(list(signal),list([5,7,12,30,50,100,150,400]),fs)
        return spectrum[1][4] #low freq
    
    def compute100_150(self,signal, fs):
        spectrum = pyeeg.bin_power(list(signal),list([5,7,12,30,50,100,150,400]),fs)
        return spectrum[1][5] #low freq
    
    def compute150_400(self,signal, fs):
        spectrum = pyeeg.bin_power(list(signal),list([5,7,12,30,50,100,150,400]),fs)
        return spectrum[1][6] #low freq
    
    def get_existing_features(self):
        """
        Define the possible set of features that will be computed. If one want to add a feature, 
        just add a function to define the operation of the feature on the data, create a class Feature.
        :return: List of names of defined features
        """  
        
        return self.features.values() #this is the list of the coded features until now      
    
    def get_features(self,feat_name):
        """
        Get Feature object defined in this class with name feat_name

        :param feat_name: name of feature to get
        :return: Feature class defined with name feat_name
        """  
        return self.features[feat_name]   
  

def H_get_selected_features(nb_streams, feature_names, channels):
    """
    Create feature objects from feature names
    """
    defined_features = DefinedFeatures()

    features = []
    #Get number of clusters, check channels were selected, create feature objects
    for i in range(nb_streams): #For each cluster
        #From feature name to feature object
        Sel_Feats = []
        for feat_name in feature_names[i]:
            Sel_Feats.append(defined_features.get_features(feat_name))
        features.append(Sel_Feats)

    return features


#################################################################################################
# COMPUTE FEATURES
def BFE(signal,Selected_Features, fs):
    """ 
    Basic_Feature_Extractor: Extract features from 1 window of 1 channel
    INFO: If no features selected, this function becomes an auto-encoder

    :param signal: signal vector of one window for one channel
    :param Selected_Features: List of features to compute of one cluster
    :return: list of extracted features
    """
    Features = []  
    for feat in Selected_Features:
        Features.append(feat.compute_feature(signal, fs))

    if not Features: #check if list is empty (no features were selected)
        return signal
    return Features 

def MFE(window, Features_To_Extract, fs):
    """ 
    Medium_Feature_Extractor: Extract features of 1 window of several channels that have the same features to extract
    
    :param window: data as 2D array (only selected channels in rows and one window of time in columns)
    :param Features_To_Extract: List of features to compute of one cluster
    :return Features: list of aggregated features from several channels
    """
    Features = []

    for idx,channel in enumerate(window):
        Features.extend(BFE(channel, Features_To_Extract, fs))

    return Features

def HFE(data_windows, Features_To_Extract, fs, is_parallel, online):
    """ 
    High Feature Extractor
    Extract features for every windows iteratively or in parallel for one cluster

    :param data_windows: list of windows as 2D array (only selected channels in rows and time in columns)
    :param Features_To_Extract: List of features to compute of one cluster
    :param win_len: length of windows to extract(in nb of points(?)), if win_len is 0 then the data is not windowed
    :param step: length of step between windows (in nb of points)
    :param is_parallel: Boolean flag, if true features will be computed in parallel through windows
    :param online: True if online mode, False if offline mode, this function prints progression only in offline mode
    :param epoch_idx: if not None, it means that there are events and HFE needs to extract epochs and not sliding window
    :return: array Xi containing features as columns and windows in rows for one cluster,
    """    
    Xi = -np.ones((len(data_windows),int(len(Features_To_Extract))*data_windows[0].shape[1])) #initialize array with correct size

    if is_parallel is False:
        #Compute features iteratively
        for idx,window in enumerate(data_windows): #for each window
            Xi[idx,:] = MFE(window.values.T,Features_To_Extract, fs)
            if not online:
                sys.stdout.write("\rProgression cluster  {:03.2f} %     ".format(idx/(len(data_windows))*100))
    else:
        #Compute features in parallel
        nb_pool = mp.cpu_count()-1
        pool = mp.Pool(nb_pool)

        MFE_feat_fixed = functools.partial(MFE, Features_To_Extract=Features_To_Extract, fs =fs)      

        indexes = list(range(len(data_windows)))

        parallel_step = int(len(indexes)/nb_pool)
        for cursor in range(0,len(indexes),parallel_step):
            if not online:
                sys.stdout.write("\rProgression cluster  {:03.2f} %     ".format(cursor/len(indexes)*100))
            Xtemp = pool.map_async(MFE_feat_fixed, [data_windows[win_idx].values.T for win_idx in indexes[cursor:cursor+parallel_step]]) 
            Xi[cursor:cursor+parallel_step,:] = Xtemp.get()
        
        pool.close()
        pool.join()             

    return Xi

def SHFE(Train, Val, Test, feature_names, channels, FSs, online, is_parallel = True):
    """ 
    Super High Feature Extractor
    Extract features for every windows iteratively or in parallel for each cluster
    
    :param Tables: list of stream tables as list of 2D array (channels in columns and time in rows): pandas DataFrame one for each stream
    :param Selected_Features: List (or tuple) of List of features to compute per cluster
    :param Selected_Channels: List (or tuple) of List of channels to compute features from per cluster
    :param win_len: length of windows to extract (in ms) if win_len is 0 then the data is not windowed
    :param step: length of step between windows (in ms)
    :param parallel: Boolean flag, if true features will be computed in parallel through windows
    :return: Training, validation and testing sets with computed features
    """
    #First start by getting the index of each window
    #indices will be the one of first stream
    Train_indices = [Train[0][i].index.values[-1] for i in range(len(Train[0]))]
    if Test is not None and Test != []:
        Test_indices = [Test[0][i].index.values[-1] for i in range(len(Test[0]))]

    if Val is not None and Val != []:
        if len(Val[0]) != 0:
            Val_indices = [Val[0][i].index.values[-1] for i in range(len(Val[0]))]
    
    #Retrieve defined features
    features = H_get_selected_features(len(Train), feature_names, channels)

    #to keep origin of features
    Feat_Origin = []

    if online == False:
        warnings.warn('FE does not work with more than 1 recording ?')

    #for each stream
    for stream_idx in range(len(Train)):
        #Train
        if online == False:
            print('Extract Features of training set')
        Train[stream_idx] = HFE(Train[stream_idx],features[stream_idx], FSs[stream_idx], is_parallel,online)
        
        if Test is not None and Test != []:
            #Test
            if online == False:
                print('Exctract Features of testing set')
            Test[stream_idx] = HFE(Test[stream_idx],features[stream_idx], FSs[stream_idx], is_parallel,online)
        
        #Validation if any
        if Val is not None and Val != []:
            if len(Val[stream_idx]) != 0:
                if online == False:
                    print('Exctract Features of validation set')
                Val[stream_idx] = HFE(Val[stream_idx],features[stream_idx], FSs[stream_idx], is_parallel,online)

        for channel in channels[stream_idx]:
            #Get origin of features
            if features[stream_idx] == []: 
                raise VAlueError('Should not be here')
                nb_feats = [[channel, 'Auto-encoded_' + str(i)] for i in range(win_len_idx)]
                Feat_Origin.extend(nb_feats)
            else:
                for feat in features[stream_idx]:
                    Feat_Origin.append([channel,feat.name])

    #concatenate extracted features for each stream
    Train = np.concatenate(Train)

    if Test is not None and Test != []:
        Test = np.concatenate(Test)

    if Val is not None and Val != []:
        Val = np.concatenate(Val)

    if not online:
        sys.stdout.write('\rINFO: Feature Extraction Finished         \n')

    Train = pd.DataFrame(Train, index = Train_indices, columns = [Feat_Origin_i[0] + '_' + Feat_Origin_i[1] for Feat_Origin_i in Feat_Origin])

    if Test is not None and Test != []:
        Test = pd.DataFrame(Test, index = Test_indices, columns = [Feat_Origin_i[0] + '_' + Feat_Origin_i[1] for Feat_Origin_i in Feat_Origin])
    
    if Val is not None and Val != []:
        if len(Val) != 0:
            Val = pd.DataFrame(Val, index = Val_indices, columns = [Feat_Origin_i[0] + '_' + Feat_Origin_i[1] for Feat_Origin_i in Feat_Origin])

    return Train, Test, Val

def epoch_extractor(event_idx, before,after, step):
    """ 
    Extract epoch indexes around each event, if step is not none, epoch are growing linearly from left side (ex: step is 100ms and
    epochs should be between -500 and 200 ms, therefore epochs will be [-500,-400],[-500,-300],...,[-500,200] otherwise it will only 
    be [-500,200]. all params should be already converted from time to indexes.
    
    :param event_idx: list of indexes of events
    :param before: nb of indexes to take at begining of event
    :param after: nb of indexes to take after event
    :param step: if None, one epoch is extracted between before and after an event. Otherwise it is window step in nb of indexes and several windows are extracted per events
    :return: epoch indices
    """
    if step is None:
        nb_win_in_epoch = 1
        step = after - before
    else:
        nb_win_in_epoch = int((after - before)/step)
    
    epoch_indexes = -np.ones((len(event_idx)*nb_win_in_epoch,2),dtype = int)
    idx = 0
    for event in event_idx:
        for i in range(1,nb_win_in_epoch+1):
            if event + before >= 0: #skip events that are too soon in recording to be epoched correctly
                
                epoch_indexes[idx,:] = [int(event + before), int(event + before + step*i)]
                
                if idx == 0 or idx == 1 or event == event_idx[-1]:
                    print(event, before, after, epoch_indexes[idx,:])
                idx += 1
    return epoch_indexes

#################################################################################################
# Online Pipeline

def online_pipeline(Tables, Selected_Features, Selected_Channels, win_len, sampling_frequencies, dimred_type, scaler, Fisher, recs):
    """ 
    Extract features iteratively for the window stored in data
    
    :param data: one window chunck of data (win_len*n_channels)
    :param Selected_Features: List of List of features to compute per cluster
    :param Selected_Channels: List of List of channels to compute features from per cluster
    :param win_len: length of windows to extract (in ms) if win_len is 0 then the data is not windowed
    :param fs: sampling frequency of signal
    :param dimred_type: Type of dimentionality reduction (PCA, FA, ICA, None)
    :param scaler: sklearn StandardScaler object to normalize data in same way as training
    :param Fisher: List of indexes of features to keep based on fisher score, if False, it will keep all features
    :return: Matrix X with features as columns (one row since it is one window)
    """

    X_online , _, data_index = SHFE(Tables, Selected_Features, Selected_Channels, win_len, sampling_frequencies, step = 1, recs=recs, is_parallel = False, online = True)
    #compute_feat(data, Selected_Features, Selected_Channels, win_len, fs, step = 1, is_parallel = False, online = True)
    X_online = X_online[0][0].reshape((-1,1))
 

    # Standardise data
    if scaler is not None:
        X_online = scaler.transform(X_online)
        
    # Apply dimentionality reduction
    if dimred_type is not None:
        X_online = dimred_type.transform(X_online) 

    #Select best features accoridng to feature score if selected
    if Fisher is not False:
        X_online = X_online[:,Fisher]
        
    return X_online,data_index


#################################################################################################
# SCORE FEATURES

def fisher(feats, observations):
    """ 
    Compute the Fisher discrimination score of all features, given its values
    for a given set of observations (matrix X)
    
    :param feat: vector of feature values or matrix X
    :param observations: vector of of observations
    :return: Fisher score of the feature 
    """

    # --------------- YOUR CODE ------------
    fisher_scores = -np.ones((feats.shape[1],))
    #First, normalize the features as said in section 1.1 of the paper
    norm_feats = (feats - np.mean(feats, axis = 0))
    for j in range(feats.shape[1]):
        sigma_j = 0 #for j = 0
        num_j = 0
        for k in range(0,2):
            print(feats, norm_feats[observations == k,j])
            print(j,k, feats.shape, norm_feats.shape)
            sigma_j += np.sum(observations == k)*np.std(norm_feats[observations == k,j])**2
            num_j += np.sum(observations == k)*np.mean(norm_feats[observations == k,j])**2 #Since values were centered beforehand, mu_j = 0   
        if sigma_j == 0:
            fisher_scores[j] = 0
        else:
            fisher_scores[j] = num_j/sigma_j
    
    return fisher_scores

#################################################################################################
# Dimentionality reduction

def Reduce_dimention(X, _type = 'PCA', n_components = None):
    """
    This fuction performs PCA, ICA or FA, it can be applied on all dataset for feature visualization,
    for training with scaler = None to create a scaler and use this function with the test set with scaler computed on training set to avoid overfitting.
    
    :param X: Matrix to be computed (samples in rows and features in columns)
    :param _type: Type of dimentionality reduction in 'PCA', 'ICA' or 'FA'
    :param n_components: number of features to keep
    :return: features transformed
    :return: dim_red object
    """
    
    if _type == 'ICA':
        # Compute Independant Components Analysis
        ica = FastICA(n_components)
        X_transformed = ica.fit_transform(X_scaled) 
        return X_transformed, ica

    if _type == 'PCA':
        # compute Principal Component Analysis
        pca = PCA(n_components)
        X_transformed = pca.fit_transform(X_scaled)
        return X_transformed, pca

    if _type == 'FA':
        # compute Factor Analysis
        fa = FactorAnalysis(n_components)
        X_transformed = fa.fit_transform(X_scaled) 
        return X_transformed, fa
    raise ValueError('Type of dimentionality reduction not understood')

