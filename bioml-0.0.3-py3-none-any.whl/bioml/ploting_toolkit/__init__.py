from .Boxplot import boxplot_div
from .Histogram import histogram_div
from .Scatter2D import scatter2D_div
from .Scatter3D import scatter3D_div
from .Timeserie import timeserie_div
from .Violin import violin_div
from .Label_plot import label_plot_div
from .Epochs import Epochs_div