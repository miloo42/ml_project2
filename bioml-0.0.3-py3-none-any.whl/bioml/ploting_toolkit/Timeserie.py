#Dash imports
import dash
import dash_core_components as dcc
from dash.dependencies import Input, Output, State
import dash_html_components as html
import plotly.graph_objs as go

import numpy as np
import datetime

def timeserie_div(X,y,time, feature_name):
    #Create list for each element of set
    Boxes = []
    

#    time = [str(t) for t in time]

    maxi = max(X)
    if maxi == 0:
        maxi = 1
        
    #Plot feature
    Boxes.append(go.Scatter(x=time, y=X, #/maxi,
                            marker={'color': 'black', 'size': 1},
                            name = 'Normalized Signal'))
    #Plot labels/targets
    if len(set(y)) < 10: # if true it will be plottable with different colors
        for i in set(y):
            temp = np.zeros((len(X),))
            temp[np.argwhere(y==i)] = 1
            Boxes.append(go.Scatter(x =time, y=temp, 
                                    fill='tozeroy',  
                                    mode= 'none', 
                                    name = 'y = ' + str(i)
                                   ))
    else: #if too many different value we just plot the labels as a curve
        Boxes.append(go.Scatter(x=time, y=y,
                            marker={'color': 'red', 'size': 1},
                            name = 'Targets'))
        

    
    return dcc.Graph(id='timeserie_plot', 
                               figure={
                                   'data': Boxes,
                                   'layout': go.Layout(title= 'timeserie of ' + feature_name,
                                   xaxis= dict( title= 'Time'))
                               })
                   