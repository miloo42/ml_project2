#Dash imports
import dash
import dash_core_components as dcc
from dash.dependencies import Input, Output, State
import dash_html_components as html
import plotly.graph_objs as go

import numpy as np

def histogram_div(X,y, feature_name):
    #Create list for each element of set
    Histograms = []
    for i in set(y):
        Histograms.append(go.Histogram(x = X[np.argwhere(y==i)].reshape(-1,), 
                                  histnorm='', 
                                  name=str(i), 
                                  autobinx=True, 
                                  opacity=0.75
                                 )
                    )
    
    return html.Div([dcc.Graph(id='histogram_plot', 
                               figure={
                                   'data': Histograms,
                                   'layout': go.Layout(title= 'Histogram of feature ' + feature_name,
                                   xaxis= dict( title= 'Values'))
                               })
                   ])