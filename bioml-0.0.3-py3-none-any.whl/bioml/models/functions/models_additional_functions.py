import numpy as np
from tensorflow.keras.utils import plot_model
from tensorflow.keras.callbacks import Callback
from tensorflow.keras.callbacks import LearningRateScheduler
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.callbacks import ModelCheckpoint
from tensorflow.keras.models import load_model

import talos as ta
from talos.utils.gpu_utils import parallel_gpu_jobs

def run_GS(train_data, train_labels, val_data, val_labels, params, model_fn, experiment_name):

    parallel_gpu_jobs(allow_growth = True, fraction = 0.95)
    scan_results = ta.Scan(train_data, train_labels, params,  model_fn, experiment_name = experiment_name,
                        x_val=val_data, y_val=val_labels)

    return scan_results

def run_GS_dataset(tr_dataset, val_data, val_labels, params, model_fn, experiment_name):

    parallel_gpu_jobs(allow_growth = True, fraction = 0.95)
    scan_results = ta.Scan(tr_dataset, train_labels, params,  model_fn, experiment_name = experiment_name,
                        x_val=val_data, y_val=val_labels)

    return scan_results

def get_summary(model,WhoAmI):
# Get a summery about the architecture and parameters. 
#
# INPUTS:  - model: the model instance created.
#          - WhoAmI: a string representing the name of the model. This will be used to save a figure of the model architecture
#
# OUTPUTS: // (just a summary of the architecture is shown in the script and a figure is saved)

    print(model.summary())
    
    # To save a picture showing the architecture 
    file_name = WhoAmI + '.png'
    plot_model(model, to_file = file_name)
    print("\nYou can visualize the architecture in the file " + WhoAmI + '.png')

def step_decay(epoch):
    #We half the the learning rate each 10 epochs
    initial_l_r = 0.01 
    drop = 0.5 
    epochs_drop = 10
    lrate = initial_l_r * np.power(drop,np.floor((1 + epoch)/epochs_drop))
    # if you want to avoid the learning rate decay, uncomment this line.
    #lrate = initial_l_r
    #print('The learning rate is : ', lrate)
    return lrate    
    
############### DEFINING OUR CUSTOMER-IMPLEMENTED CALLBACKS ###############

# ATTENTION --> THESE CALLBACKS HAVE NOT BEEN USED FINALLY. THE CODE HAS TO BE CHECKED AND (PROBABLY) CHANGED.

class ThresholdEarlyStopping(Callback):
# The ida was to implement a callback able to monitor a chosen parameter (val_loss by default) and to stop whenever this parameters reaches a certain threshold. The model corresponding to this last epoch would be saved.
    def __init__(self, filename, nbr_epochs, monitor = 'val_loss', threshold = 1.0, verbose = 0):
        super(Callback, self).__init__()
        self.monitor = monitor
        self.threshold = threshold
        self.verbose = verbose
        self.filename = filename
        self.nbr_epochs = nbr_epochs
        self.current_loss = np.Inf
        self.epoch_number = 0
        
    def on_epoch_end(self, epoch, logs = {}):
        self.current_loss = logs.get(self.monitor)
        self.epoch_number = self.epoch_number + 1
        if self.current_loss is not None:
            if self.current_loss < self.threshold:
                self.model.stop_training = True
                
    def on_train_end(self, logs = None):
        if self.epoch_number < self.nbr_epochs:
            if self.verbose > 0:
                print('\nEarly stopping because of threshold reaching!')
                print('Reached ' + self.monitor + ' value :',self.current_loss)
            self.model.save(self.filename)
                
class RestoreAndSaveBestModel(Callback): 
# The idea was to have a callback that, in the case where the threshold for the ThresholdEarlyStopping was not reached, restores the best model among the epochs performed and save it. 
    def __init__(self,filename,nbr_epochs,monitor = 'val_loss',verbose = 0):
        super(Callback, self).__init__()
        self.monitor = monitor
        self.verbose = verbose
        self.filename = filename
        self.nbr_epochs = nbr_epochs
        self.monitor_op = np.less
        self.best_weights = None
        self.best = np.Inf
        self.epoch_number = 0
        
    def on_epoch_end(self, epoch, logs = None):
        current = self.get_monitor_value(logs)
        self.epoch_number = self.epoch_number + 1
        
        if current is not None:
            if self.monitor_op(current, self.best):
                self.best = current
                self.best_weights = self.model.get_weights()
             
    def on_train_end(self, logs = None):
        if self.nbr_epochs == self.epoch_number:
            if self.verbose > 0:
                print('Restoring model weights from the best model!')
                print('Best ' + self.monitor + ' reached :',self.best)
            self.model.set_weights(self.best_weights)
            self.model.save(self.filename)
            
    def get_monitor_value(self, logs):
        monitor_value = logs.get(self.monitor)
        return monitor_value